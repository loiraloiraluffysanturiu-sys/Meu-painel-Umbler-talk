import { Link, useLocation } from 'react-router-dom';

export default function Sidebar() {
  const location = useLocation();

  const menuItems = [
    { path: '/', label: '🤖 Agentes', icon: '📋' },
    { path: '/agents/new', label: '➕ Novo Agente', icon: '✨' }
  ];

  return (
    <div className="glassmorphism" style={{
      width: '250px',
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '10px'
    }}>
      <div style={{ marginBottom: '30px', textAlign: 'center' }}>
        <img src="/logo.svg" alt="Coca Fria" style={{ width: '100%', maxWidth: '180px' }} />
      </div>

      {menuItems.map((item) => (
        <Link
          key={item.path}
          to={item.path}
          style={{
            textDecoration: 'none',
            padding: '12px 16px',
            borderRadius: '8px',
            color: location.pathname === item.path ? '#00d9ff' : '#e0e0e0',
            background: location.pathname === item.path ? 'rgba(0, 217, 255, 0.1)' : 'transparent',
            border: location.pathname === item.path ? '1px solid #00d9ff' : '1px solid transparent',
            transition: 'all 0.3s',
            display: 'flex',
            alignItems: 'center',
            gap: '10px'
          }}
        >
          <span>{item.icon}</span>
          <span>{item.label}</span>
        </Link>
      ))}

      <div style={{ marginTop: 'auto', padding: '16px', textAlign: 'center', fontSize: '12px', color: '#666' }}>
        <p>Coca Fria v1.0</p>
        <p>Sistema Multi-Agente</p>
      </div>
    </div>
  );
}
