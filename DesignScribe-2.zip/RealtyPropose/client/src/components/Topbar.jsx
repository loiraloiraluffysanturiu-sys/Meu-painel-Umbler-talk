export default function Topbar() {
  return (
    <div className="glassmorphism" style={{
      padding: '15px 25px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      margin: '10px',
      marginBottom: '0'
    }}>
      <h2 className="neon-text" style={{ fontSize: '20px' }}>
        Sistema Multi-Agente WhatsApp
      </h2>
      
      <div style={{ display: 'flex', gap: '15px', alignItems: 'center' }}>
        <div style={{
          background: 'rgba(0, 217, 255, 0.2)',
          padding: '8px 16px',
          borderRadius: '20px',
          fontSize: '14px'
        }}>
          🟢 Online
        </div>
      </div>
    </div>
  );
}
