import { useState } from 'react';

export default function Step3_Knowledge({ formData, setFormData }) {
  const [newKnowledge, setNewKnowledge] = useState({ title: '', content: '' });

  const addKnowledge = () => {
    if (newKnowledge.title && newKnowledge.content) {
      setFormData({
        ...formData,
        knowledge: [...(formData.knowledge || []), { ...newKnowledge, id: Date.now() }]
      });
      setNewKnowledge({ title: '', content: '' });
    }
  };

  const removeKnowledge = (id) => {
    setFormData({
      ...formData,
      knowledge: formData.knowledge.filter(k => k.id !== id)
    });
  };

  return (
    <div>
      <h3 className="neon-text" style={{ marginBottom: '25px', fontSize: '22px' }}>
        3. Base de Conhecimento
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div className="glassmorphism" style={{ padding: '20px' }}>
          <h4 style={{ marginBottom: '15px', color: '#00d9ff' }}>Adicionar Conhecimento</h4>
          
          <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
            <input
              type="text"
              placeholder="Título (ex: Produtos, FAQ, Política)"
              value={newKnowledge.title}
              onChange={(e) => setNewKnowledge({ ...newKnowledge, title: e.target.value })}
              style={{ width: '100%' }}
            />
            
            <textarea
              placeholder="Conteúdo do conhecimento..."
              value={newKnowledge.content}
              onChange={(e) => setNewKnowledge({ ...newKnowledge, content: e.target.value })}
              style={{ width: '100%', minHeight: '100px' }}
            />
            
            <button className="btn-primary" onClick={addKnowledge} type="button">
              ➕ Adicionar
            </button>
          </div>
        </div>

        {formData.knowledge && formData.knowledge.length > 0 && (
          <div>
            <h4 style={{ marginBottom: '15px', color: '#00d9ff' }}>
              Conhecimentos Adicionados ({formData.knowledge.length})
            </h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              {formData.knowledge.map((k) => (
                <div
                  key={k.id}
                  className="glassmorphism"
                  style={{ padding: '15px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
                >
                  <div>
                    <strong style={{ color: '#00d9ff' }}>{k.title}</strong>
                    <p style={{ color: '#b0b0b0', fontSize: '14px', marginTop: '5px' }}>
                      {k.content.substring(0, 80)}...
                    </p>
                  </div>
                  <button
                    className="btn-danger"
                    onClick={() => removeKnowledge(k.id)}
                    style={{ padding: '6px 12px', fontSize: '13px' }}
                    type="button"
                  >
                    Remover
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
