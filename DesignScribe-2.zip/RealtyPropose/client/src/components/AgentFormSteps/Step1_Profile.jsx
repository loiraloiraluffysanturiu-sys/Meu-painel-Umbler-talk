export default function Step1_Profile({ formData, setFormData }) {
  return (
    <div>
      <h3 className="neon-text" style={{ marginBottom: '25px', fontSize: '22px' }}>
        1. Perfil do Agente
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Nome do Agente *
          </label>
          <input
            type="text"
            placeholder="Ex: Atendente Vendas"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            style={{ width: '100%' }}
            required
          />
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Tipo
          </label>
          <select
            value={formData.type}
            onChange={(e) => setFormData({ ...formData, type: e.target.value })}
            style={{ width: '100%' }}
          >
            <option value="Atendimento">Atendimento</option>
            <option value="Vendas">Vendas</option>
            <option value="Suporte">Suporte</option>
            <option value="Marketing">Marketing</option>
            <option value="Geral">Geral</option>
          </select>
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Descrição
          </label>
          <textarea
            placeholder="Descreva a função deste agente..."
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            style={{ width: '100%', minHeight: '100px' }}
          />
        </div>
      </div>
    </div>
  );
}
