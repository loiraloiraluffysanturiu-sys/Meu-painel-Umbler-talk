export default function Step2_Behavior({ formData, setFormData }) {
  const updateBehavior = (key, value) => {
    setFormData({
      ...formData,
      behavior: { ...formData.behavior, [key]: value }
    });
  };

  return (
    <div>
      <h3 className="neon-text" style={{ marginBottom: '25px', fontSize: '22px' }}>
        2. Comportamento
      </h3>

      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Personalidade
          </label>
          <input
            type="text"
            placeholder="Ex: Amigável e prestativo"
            value={formData.behavior.personality || ''}
            onChange={(e) => updateBehavior('personality', e.target.value)}
            style={{ width: '100%' }}
          />
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Tom de Voz
          </label>
          <select
            value={formData.behavior.tone || 'professional'}
            onChange={(e) => updateBehavior('tone', e.target.value)}
            style={{ width: '100%' }}
          >
            <option value="professional">Profissional</option>
            <option value="friendly">Amigável</option>
            <option value="casual">Casual</option>
            <option value="formal">Formal</option>
          </select>
        </div>

        <div>
          <label style={{ display: 'block', marginBottom: '8px', color: '#00d9ff' }}>
            Instruções Personalizadas
          </label>
          <textarea
            placeholder="Instruções específicas de como o agente deve se comportar..."
            value={formData.behavior.instructions || ''}
            onChange={(e) => updateBehavior('instructions', e.target.value)}
            style={{ width: '100%', minHeight: '120px' }}
          />
        </div>

        <div>
          <label style={{ display: 'flex', alignItems: 'center', gap: '10px', cursor: 'pointer' }}>
            <input
              type="checkbox"
              checked={formData.behavior.autoReply || false}
              onChange={(e) => updateBehavior('autoReply', e.target.checked)}
            />
            <span>Resposta Automática</span>
          </label>
        </div>
      </div>
    </div>
  );
}
