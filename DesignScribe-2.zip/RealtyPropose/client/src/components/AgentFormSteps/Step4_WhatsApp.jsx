export default function Step4_WhatsApp({ formData }) {
  return (
    <div>
      <h3 className="neon-text" style={{ marginBottom: '25px', fontSize: '22px' }}>
        4. Configuração WhatsApp
      </h3>

      <div className="glassmorphism" style={{ padding: '30px', textAlign: 'center' }}>
        <div style={{ marginBottom: '30px' }}>
          <div style={{ fontSize: '60px', marginBottom: '20px' }}>📱</div>
          <h4 style={{ color: '#00d9ff', marginBottom: '15px' }}>Pronto para Conectar!</h4>
          <p style={{ color: '#b0b0b0', marginBottom: '10px' }}>
            Agente: <strong style={{ color: '#00d9ff' }}>{formData.name}</strong>
          </p>
          <p style={{ color: '#888', fontSize: '14px' }}>
            Após criar o agente, você poderá conectá-lo ao WhatsApp escaneando o QR Code
          </p>
        </div>

        <div style={{
          background: 'rgba(0, 217, 255, 0.1)',
          border: '1px solid rgba(0, 217, 255, 0.3)',
          borderRadius: '12px',
          padding: '20px',
          textAlign: 'left'
        }}>
          <h5 style={{ color: '#00d9ff', marginBottom: '15px' }}>ℹ️ Informações Importantes:</h5>
          <ul style={{ color: '#b0b0b0', fontSize: '14px', lineHeight: '1.8' }}>
            <li>Cada agente precisa de um número WhatsApp exclusivo</li>
            <li>A sessão será salva automaticamente</li>
            <li>O agente responderá mensagens automaticamente</li>
            <li>Você pode reconectar a qualquer momento</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
