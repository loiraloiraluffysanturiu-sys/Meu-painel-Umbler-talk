export default function Spinner({ size = 40 }) {
  return (
    <div style={{ 
      display: 'inline-block',
      width: size,
      height: size,
      border: '3px solid rgba(0, 217, 255, 0.3)',
      borderTopColor: '#00d9ff',
      borderRadius: '50%',
      animation: 'spin 0.8s linear infinite'
    }}>
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
