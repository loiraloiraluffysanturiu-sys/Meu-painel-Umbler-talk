import { motion, AnimatePresence } from 'framer-motion';

export default function QrModal({ isOpen, onClose, qrCode, agentName }) {
  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: 'rgba(0, 0, 0, 0.8)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          zIndex: 1000
        }}
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.8, y: 50 }}
          animate={{ scale: 1, y: 0 }}
          exit={{ scale: 0.8, y: 50 }}
          className="glassmorphism neon-border"
          style={{
            padding: '30px',
            maxWidth: '400px',
            textAlign: 'center'
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <h2 className="neon-text" style={{ marginBottom: '20px' }}>
            Conectar WhatsApp
          </h2>
          
          <p style={{ marginBottom: '20px', color: '#b0b0b0' }}>
            {agentName || 'Agente'}
          </p>

          {qrCode ? (
            <div style={{
              background: 'white',
              padding: '20px',
              borderRadius: '12px',
              marginBottom: '20px'
            }}>
              <img 
                src={qrCode} 
                alt="QR Code WhatsApp" 
                style={{ width: '100%', maxWidth: '250px' }} 
              />
            </div>
          ) : (
            <div style={{ padding: '40px' }}>
              <div className="spinner" />
              <p style={{ marginTop: '20px', color: '#b0b0b0' }}>
                Gerando QR Code...
              </p>
            </div>
          )}

          <p style={{ fontSize: '14px', color: '#888', marginBottom: '20px' }}>
            Escaneie o QR Code com o WhatsApp do celular
          </p>

          <button className="btn-secondary" onClick={onClose}>
            Fechar
          </button>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
