import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';
import AgentsList from './pages/AgentsList';
import AgentWizard from './pages/AgentWizard';
import AgentDetail from './pages/AgentDetail';

function App() {
  return (
    <Router>
      <div style={{ display: 'flex', minHeight: '100vh', background: '#0a0a0f' }}>
        <Sidebar />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
          <Topbar />
          <main style={{ flex: 1, padding: '20px', overflowY: 'auto' }}>
            <Routes>
              <Route path="/" element={<AgentsList />} />
              <Route path="/agents/new" element={<AgentWizard />} />
              <Route path="/agents/:id" element={<AgentDetail />} />
            </Routes>
          </main>
        </div>
      </div>
    </Router>
  );
}

export default App;
