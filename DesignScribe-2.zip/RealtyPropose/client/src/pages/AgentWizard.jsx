import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import Button from '../components/ui/Button';
import Step1_Profile from '../components/AgentFormSteps/Step1_Profile';
import Step2_Behavior from '../components/AgentFormSteps/Step2_Behavior';
import Step3_Knowledge from '../components/AgentFormSteps/Step3_Knowledge';
import Step4_WhatsApp from '../components/AgentFormSteps/Step4_WhatsApp';

const API_URL = '';

export default function AgentWizard() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    type: 'Atendimento',
    description: '',
    behavior: {
      personality: '',
      tone: 'professional',
      instructions: '',
      autoReply: true
    },
    knowledge: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const steps = [
    { number: 1, title: 'Perfil', component: Step1_Profile },
    { number: 2, title: 'Comportamento', component: Step2_Behavior },
    { number: 3, title: 'Conhecimento', component: Step3_Knowledge },
    { number: 4, title: 'WhatsApp', component: Step4_WhatsApp }
  ];

  const CurrentStepComponent = steps[currentStep - 1].component;

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!formData.name) {
      alert('Nome do agente é obrigatório!');
      setCurrentStep(1);
      return;
    }

    setIsSubmitting(true);

    try {
      const response = await axios.post(`${API_URL}/api/agents`, {
        name: formData.name,
        type: formData.type,
        description: formData.description,
        behavior: JSON.stringify(formData.behavior)
      });

      const agentId = response.data.id;

      // Adicionar conhecimento
      for (const knowledge of formData.knowledge || []) {
        await axios.post(`${API_URL}/api/agents/${agentId}/knowledge`, {
          title: knowledge.title,
          content: knowledge.content,
          metadata: {}
        });
      }

      alert('Agente criado com sucesso!');
      navigate('/');
    } catch (error) {
      console.error('Erro ao criar agente:', error);
      alert('Erro ao criar agente. Verifique se o backend está rodando.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div>
      <h1 className="neon-text" style={{ fontSize: '28px', marginBottom: '30px' }}>
        ✨ Criar Novo Agente
      </h1>

      {/* Progress Bar */}
      <div className="glassmorphism" style={{ padding: '20px', marginBottom: '30px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '15px' }}>
          {steps.map((step) => (
            <div
              key={step.number}
              style={{
                flex: 1,
                textAlign: 'center',
                color: currentStep >= step.number ? '#00d9ff' : '#666'
              }}
            >
              <div style={{
                width: '40px',
                height: '40px',
                borderRadius: '50%',
                background: currentStep >= step.number ? 'linear-gradient(135deg, #00d9ff, #0099ff)' : 'rgba(100, 100, 100, 0.3)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                margin: '0 auto 10px',
                fontWeight: 'bold'
              }}>
                {step.number}
              </div>
              <div style={{ fontSize: '14px' }}>{step.title}</div>
            </div>
          ))}
        </div>
        <div style={{ background: 'rgba(100, 100, 100, 0.3)', height: '4px', borderRadius: '2px', position: 'relative' }}>
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep - 1) / (steps.length - 1)) * 100}%` }}
            style={{
              height: '100%',
              background: 'linear-gradient(90deg, #00d9ff, #0099ff)',
              borderRadius: '2px'
            }}
          />
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit}>
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="glassmorphism"
          style={{ padding: '30px', marginBottom: '20px' }}
        >
          <CurrentStepComponent formData={formData} setFormData={setFormData} />
        </motion.div>

        {/* Navigation Buttons */}
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: '15px' }}>
          <div style={{ display: 'flex', gap: '15px' }}>
            <Button
              variant="secondary"
              onClick={() => navigate('/')}
              type="button"
            >
              Cancelar
            </Button>
            {currentStep > 1 && (
              <Button
                variant="secondary"
                onClick={handlePrevious}
                type="button"
              >
                ← Anterior
              </Button>
            )}
          </div>

          <div>
            {currentStep < steps.length ? (
              <Button onClick={handleNext} type="button">
                Próximo →
              </Button>
            ) : (
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? 'Criando...' : '✅ Criar Agente'}
              </Button>
            )}
          </div>
        </div>
      </form>
    </div>
  );
}
