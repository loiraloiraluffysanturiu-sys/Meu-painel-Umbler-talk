import { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import io from 'socket.io-client';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import QrModal from '../components/QrModal';

const API_URL = '';

export default function AgentDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [agent, setAgent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [recipientNumber, setRecipientNumber] = useState('');
  const [socket, setSocket] = useState(null);
  const [qrModal, setQrModal] = useState({ isOpen: false, qrCode: null });
  const messagesEndRef = useRef(null);

  useEffect(() => {
    loadAgent();
    loadConversations();

    const newSocket = io(`${API_URL}/app`);
    setSocket(newSocket);

    newSocket.on(`message:${id}`, (data) => {
      setMessages(prev => [...prev, {
        role: data.from === id ? 'agent' : 'user',
        sender: data.from,
        message_text: data.text,
        created_at: data.timestamp
      }]);
    });

    newSocket.on(`qr:${id}`, (data) => {
      setQrModal({ isOpen: true, qrCode: data.qr });
    });

    newSocket.on(`authenticated:${id}`, () => {
      setQrModal({ isOpen: false, qrCode: null });
      alert('WhatsApp conectado com sucesso!');
    });

    return () => newSocket.close();
  }, [id]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const loadAgent = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/agents/${id}`);
      setAgent(response.data);
    } catch (error) {
      console.error('Erro ao carregar agente:', error);
      alert('Erro ao carregar agente');
      navigate('/');
    } finally {
      setLoading(false);
    }
  };

  const loadConversations = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/messages/conversations/${id}`);
      setMessages(response.data.reverse());
    } catch (error) {
      console.error('Erro ao carregar conversas:', error);
    }
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim() || !recipientNumber.trim()) {
      alert('Digite o número e a mensagem!');
      return;
    }

    try {
      await axios.post(`${API_URL}/api/messages/send`, {
        agent_id: id,
        to: recipientNumber,
        text: newMessage
      });
      setNewMessage('');
    } catch (error) {
      console.error('Erro ao enviar mensagem:', error);
      alert('Erro ao enviar mensagem');
    }
  };

  const handleSimulate = async () => {
    try {
      await axios.post(`${API_URL}/api/messages/simulate`, {
        agent_id: id,
        from: recipientNumber || '5511999999999',
        text: 'Olá! Preciso de ajuda.'
      });
    } catch (error) {
      console.error('Erro ao simular:', error);
    }
  };

  const handleConnect = async () => {
    try {
      setQrModal({ isOpen: true, qrCode: null });
      await axios.post(`${API_URL}/api/agents/${id}/connect-whatsapp?action=start`);
    } catch (error) {
      console.error('Erro ao conectar:', error);
      setQrModal({ isOpen: false, qrCode: null });
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '400px' }}>
        <Spinner size={50} />
      </div>
    );
  }

  if (!agent) return null;

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div>
          <Button variant="secondary" onClick={() => navigate('/')} style={{ marginBottom: '15px' }}>
            ← Voltar
          </Button>
          <h1 className="neon-text" style={{ fontSize: '28px' }}>{agent.name}</h1>
          <p style={{ color: '#b0b0b0', marginTop: '8px' }}>{agent.description}</p>
        </div>
        <Button onClick={handleConnect}>
          📱 Conectar WhatsApp
        </Button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 350px', gap: '20px' }}>
        {/* Chat Area */}
        <div className="glassmorphism" style={{ padding: '20px', display: 'flex', flexDirection: 'column', height: '600px' }}>
          <h3 className="neon-text" style={{ marginBottom: '20px' }}>💬 Conversas</h3>
          
          {/* Messages */}
          <div style={{ flex: 1, overflowY: 'auto', marginBottom: '20px', display: 'flex', flexDirection: 'column', gap: '10px' }}>
            {messages.length === 0 ? (
              <div style={{ textAlign: 'center', color: '#666', paddingTop: '50px' }}>
                Nenhuma conversa ainda
              </div>
            ) : (
              messages.map((msg, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{
                    alignSelf: msg.role === 'agent' ? 'flex-end' : 'flex-start',
                    maxWidth: '70%'
                  }}
                >
                  <div style={{
                    background: msg.role === 'agent' ? 'linear-gradient(135deg, #00d9ff, #0099ff)' : 'rgba(50, 50, 60, 0.8)',
                    padding: '12px 16px',
                    borderRadius: '12px',
                    color: 'white'
                  }}>
                    <div style={{ fontSize: '11px', opacity: 0.7, marginBottom: '4px' }}>
                      {msg.role === 'agent' ? '🤖 Agente' : `👤 ${msg.sender}`}
                    </div>
                    <div>{msg.message_text}</div>
                    <div style={{ fontSize: '10px', opacity: 0.6, marginTop: '4px' }}>
                      {new Date(msg.created_at).toLocaleTimeString()}
                    </div>
                  </div>
                </motion.div>
              ))
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div style={{ display: 'flex', gap: '10px' }}>
            <input
              type="text"
              placeholder="Número (ex: 5511999999999)"
              value={recipientNumber}
              onChange={(e) => setRecipientNumber(e.target.value)}
              style={{ flex: 1 }}
            />
            <input
              type="text"
              placeholder="Digite uma mensagem..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              style={{ flex: 2 }}
            />
            <Button onClick={handleSendMessage}>Enviar</Button>
          </div>
        </div>

        {/* Info Panel */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <div className="glassmorphism" style={{ padding: '20px' }}>
            <h4 className="neon-text" style={{ marginBottom: '15px' }}>ℹ️ Informações</h4>
            <div style={{ fontSize: '14px', color: '#b0b0b0', lineHeight: '1.8' }}>
              <p><strong>Tipo:</strong> {agent.type}</p>
              <p><strong>Criado:</strong> {new Date(agent.created_at).toLocaleDateString()}</p>
            </div>
          </div>

          <div className="glassmorphism" style={{ padding: '20px' }}>
            <h4 className="neon-text" style={{ marginBottom: '15px' }}>🧪 Teste</h4>
            <Button variant="secondary" onClick={handleSimulate} style={{ width: '100%' }}>
              Simular Mensagem
            </Button>
            <p style={{ fontSize: '12px', color: '#666', marginTop: '10px' }}>
              Simula uma mensagem recebida para testar o agente
            </p>
          </div>

          <div className="glassmorphism" style={{ padding: '20px' }}>
            <h4 className="neon-text" style={{ marginBottom: '15px' }}>⚙️ Ações</h4>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <Button variant="secondary" style={{ width: '100%' }}>
                Editar
              </Button>
              <Button variant="danger" style={{ width: '100%' }} onClick={() => {
                if (confirm('Excluir agente?')) {
                  axios.delete(`${API_URL}/api/agents/${id}`).then(() => navigate('/'));
                }
              }}>
                Excluir
              </Button>
            </div>
          </div>
        </div>
      </div>

      <QrModal
        isOpen={qrModal.isOpen}
        onClose={() => setQrModal({ isOpen: false, qrCode: null })}
        qrCode={qrModal.qrCode}
        agentName={agent.name}
      />
    </div>
  );
}
