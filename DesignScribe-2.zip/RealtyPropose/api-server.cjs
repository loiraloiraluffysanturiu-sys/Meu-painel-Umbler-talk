// Simple API server for Coca Fria on port 3001
const express = require('express');
const cors = require('cors');
const Database = require('better-sqlite3');
const path = require('path');
const { randomUUID } = require('crypto');

const app = express();
const PORT = 3001;

// Database
const db = new Database(path.join(__dirname, 'database/db.sqlite'));

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS Agents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT,
    description TEXT,
    behavior TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS KnowledgeItems (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    title TEXT,
    content TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS Channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    type TEXT DEFAULT 'whatsapp',
    status TEXT DEFAULT 'disconnected',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS Conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    channel_id INTEGER,
    role TEXT,
    sender TEXT,
    message_text TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE,
    FOREIGN KEY (channel_id) REFERENCES Channels(id) ON DELETE CASCADE
  );
`);

app.use(cors());
app.use(express.json());

// Routes
app.get('/api/agents', (req, res) => {
  const agents = db.prepare('SELECT * FROM Agents ORDER BY created_at DESC').all();
  res.json(agents);
});

app.get('/api/agents/:id', (req, res) => {
  const agent = db.prepare('SELECT * FROM Agents WHERE id = ?').get(req.params.id);
  if (!agent) return res.status(404).json({ error: 'Agente não encontrado' });
  res.json(agent);
});

app.post('/api/agents', (req, res) => {
  const { name, type, description, behavior } = req.body;
  if (!name) return res.status(400).json({ error: 'Nome é obrigatório' });
  
  const id = randomUUID();
  const behaviorStr = typeof behavior === 'object' ? JSON.stringify(behavior) : behavior;
  
  db.prepare('INSERT INTO Agents (id, name, type, description, behavior) VALUES (?, ?, ?, ?, ?)')
    .run(id, name, type || '', description || '', behaviorStr || '{}');
  
  db.prepare('INSERT INTO Channels (agent_id, type, status) VALUES (?, ?, ?)')
    .run(id, 'whatsapp', 'disconnected');
  
  res.status(201).json({ id, name, type, description, behavior: behaviorStr });
});

app.put('/api/agents/:id', (req, res) => {
  const { name, type, description, behavior } = req.body;
  const behaviorStr = behavior && typeof behavior === 'object' ? JSON.stringify(behavior) : behavior;
  
  db.prepare(`
    UPDATE Agents SET
      name = COALESCE(?, name),
      type = COALESCE(?, type),
      description = COALESCE(?, description),
      behavior = COALESCE(?, behavior),
      updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(name, type, description, behaviorStr, req.params.id);
  
  res.json({ id: req.params.id, name, type, description });
});

app.delete('/api/agents/:id', (req, res) => {
  db.prepare('DELETE FROM Agents WHERE id = ?').run(req.params.id);
  res.json({ success: true, message: 'Agente excluído' });
});

app.post('/api/agents/:id/clone', (req, res) => {
  const original = db.prepare('SELECT * FROM Agents WHERE id = ?').get(req.params.id);
  if (!original) return res.status(404).json({ error: 'Agente não encontrado' });
  
  const newId = randomUUID();
  db.prepare('INSERT INTO Agents (id, name, type, description, behavior) VALUES (?, ?, ?, ?, ?)')
    .run(newId, `${original.name} (Cópia)`, original.type, original.description, original.behavior);
  
  db.prepare('INSERT INTO Channels (agent_id, type, status) VALUES (?, ?, ?)')
    .run(newId, 'whatsapp', 'disconnected');
  
  res.status(201).json({ id: newId, ...original, name: `${original.name} (Cópia)` });
});

app.post('/api/agents/:id/knowledge', (req, res) => {
  const { title, content, metadata } = req.body;
  const metadataStr = metadata && typeof metadata === 'object' ? JSON.stringify(metadata) : metadata;
  
  const result = db.prepare('INSERT INTO KnowledgeItems (agent_id, title, content, metadata) VALUES (?, ?, ?, ?)')
    .run(req.params.id, title, content, metadataStr || '{}');
  
  res.status(201).json({ id: result.lastInsertRowid, agent_id: req.params.id, title, content });
});

app.get('/api/messages/conversations/:agent_id', (req, res) => {
  const conversations = db.prepare('SELECT * FROM Conversations WHERE agent_id = ? ORDER BY created_at ASC LIMIT 50')
    .all(req.params.agent_id);
  res.json(conversations);
});

app.post('/api/messages/send', (req, res) => {
  const { agent_id, to, text } = req.body;
  const result = db.prepare('INSERT INTO Conversations (agent_id, role, sender, message_text, metadata) VALUES (?, ?, ?, ?, ?)')
    .run(agent_id, 'agent', agent_id, text, JSON.stringify({ to }));
  res.status(201).json({ id: result.lastInsertRowid, agent_id, role: 'agent', sender: agent_id, message_text: text });
});

app.post('/api/messages/simulate', (req, res) => {
  const { agent_id, from, text } = req.body;
  const result = db.prepare('INSERT INTO Conversations (agent_id, role, sender, message_text) VALUES (?, ?, ?, ?)')
    .run(agent_id, 'user', from, text);
  res.status(201).json({ id: result.lastInsertRowid, agent_id, role: 'user', sender: from, message_text: text });
});

app.post('/api/agents/:id/connect-whatsapp', (req, res) => {
  res.json({ message: 'WhatsApp connection not available in Replit' });
});

app.listen(PORT, () => {
  console.log(`✅ Coca Fria API Server running on http://localhost:${PORT}`);
});
