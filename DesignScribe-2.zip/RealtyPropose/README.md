# 🥤 COCA FRIA - Sistema Multi-Agente WhatsApp

Sistema completo de agentes de IA para WhatsApp com interface web, backend Node.js + Python e integração com LLaMA.

## 📋 Requisitos

### Windows
- Node.js >= 18 ([Download](https://nodejs.org/))
- Python >= 3.10 ([Download](https://www.python.org/))
- Git (opcional, para build do llama.cpp)

### Linux/Mac (Replit)
- Node.js >= 18
- Python >= 3.10

## 🚀 Instalação Rápida

### Windows

1. **Clone ou baixe o projeto**
2. **Execute o script de inicialização:**
   ```bash
   start.bat
   ```

O script irá:
- Instalar todas as dependências automaticamente
- Iniciar os 3 serviços (Backend Node, Backend Python, Frontend)
- Abrir o navegador automaticamente

### Linux/Mac/Replit

```bash
chmod +x start.sh
./start.sh
```

## 🌐 Acessar o Sistema

Após iniciar, acesse:
- **Frontend:** http://localhost:5173
- **API Node.js:** http://localhost:3001
- **API Python:** http://localhost:8000

## 📁 Estrutura do Projeto

```
coca-fria/
├── frontend/          # React + Vite
├── backend-node/      # Express + Socket.IO + SQLite
├── backend-python/    # Flask + IA (modo demo/llama)
├── database/          # SQLite
├── llama.cpp/         # LLaMA local (opcional)
├── logs/              # Logs dos serviços
└── start.bat/sh       # Scripts de inicialização
```

## 🤖 Usando o Sistema

### 1. Criar um Agente

1. Acesse http://localhost:5173
2. Clique em "➕ Novo Agente"
3. Preencha os 4 passos do wizard:
   - **Perfil:** Nome, tipo, descrição
   - **Comportamento:** Personalidade, tom de voz
   - **Conhecimento:** Base de conhecimento
   - **WhatsApp:** Confirmação
4. Clique em "Criar Agente"

### 2. Conectar WhatsApp

1. Na lista de agentes, clique em "Conectar"
2. Escaneie o QR Code com WhatsApp
3. Aguarde autenticação
4. Pronto! O agente está ativo

### 3. Testar Conversas

- Vá em "Ver" no agente
- Use o chat para enviar mensagens
- Ou clique em "Simular Mensagem" para teste

## 🧠 Modo IA

### Modo Demo (Padrão)
O sistema inicia em modo demo com respostas simuladas.

### Modo LLaMA (Avançado)

Para usar IA real local:

#### Windows:
```powershell
# 1. Compile o llama.cpp
cd llama.cpp
.\build-windows.ps1

# 2. Baixe o modelo
# Coloque LLaMA-Pro-8B-Instruct.gguf em llama.cpp/models/

# 3. Configure
# Edite backend-python/config.yaml:
mode: llama

# 4. Reinicie o backend Python
```

#### Linux:
```bash
# 1. Clone e compile
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
make

# 2. Baixe modelo e configure conforme acima
```

## 🔧 Configuração

### Backend Node.js
Edite `backend-node/.env`:
```env
PORT=3001
FRONTEND_URL=http://localhost:5173
PYTHON_API_URL=http://localhost:8000
```

### Backend Python
Edite `backend-python/config.yaml`:
```yaml
mode: demo              # ou 'llama'
model_path: "../llama.cpp/models/LLaMA-Pro-8B-Instruct.gguf"
host: "0.0.0.0"
port: 8000
```

## 📝 Banco de Dados

SQLite em `database/db.sqlite`

Tabelas:
- **Agents:** Agentes cadastrados
- **KnowledgeItems:** Base de conhecimento
- **Channels:** Canais WhatsApp
- **Conversations:** Histórico de conversas

## 🔒 Segurança

**IMPORTANTE:** Este sistema NÃO tem autenticação por design (uso local).

Para proteger:
- Use apenas em rede local/privada
- Configure firewall/VPN se necessário
- Não exponha portas publicamente

## 🛠️ Desenvolvimento

### Estrutura de APIs

#### Node.js (Port 3001)
```
GET    /api/agents              # Listar agentes
POST   /api/agents              # Criar agente
GET    /api/agents/:id          # Buscar agente
PUT    /api/agents/:id          # Atualizar agente
DELETE /api/agents/:id          # Deletar agente
POST   /api/agents/:id/clone    # Clonar agente
POST   /api/agents/:id/connect-whatsapp  # Conectar WhatsApp

GET    /api/messages/conversations/:agent_id  # Buscar conversas
POST   /api/messages/send       # Enviar mensagem
POST   /api/messages/simulate   # Simular mensagem
```

#### Python (Port 8000)
```
POST /api/generate    # Gerar resposta IA
GET  /api/health      # Status
GET  /api/config      # Configuração
```

### Socket.IO
Namespace: `/app`

Eventos:
- `qr:{agent_id}` - QR Code gerado
- `authenticated:{agent_id}` - WhatsApp autenticado
- `ready:{agent_id}` - Cliente pronto
- `message:{agent_id}` - Nova mensagem

## 📦 Dependências

### Node.js
- express, socket.io, axios
- sqlite3, winston, cors
- qrcode, uuid

### Python
- flask, flask-cors
- pyyaml, requests

### Frontend
- react, react-router-dom
- axios, socket.io-client
- framer-motion

## 🐛 Troubleshooting

### Backend não inicia
```bash
# Verificar logs
cat logs/node.log
cat logs/python.log
```

### Erro ao conectar WhatsApp
- Verifique se o backend Node está rodando
- Confirme que Socket.IO está conectado
- Tente reconectar o agente

### IA não responde
- Modo demo: deve responder com "[DEMO MODE]..."
- Modo llama: verifique se modelo existe e binário compilado

## 📄 Licença

Projeto open-source para uso educacional e comercial.

## 🆘 Suporte

Para issues e dúvidas:
1. Verifique os logs em `logs/`
2. Confirme que todos os serviços estão rodando
3. Teste com modo demo primeiro

---

**Coca Fria v1.0** - Sistema Multi-Agente WhatsApp 🥤🤖
