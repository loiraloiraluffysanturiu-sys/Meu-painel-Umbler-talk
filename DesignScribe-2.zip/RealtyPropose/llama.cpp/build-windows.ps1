# Script PowerShell para compilar llama.cpp no Windows

Write-Host "===================================" -ForegroundColor Cyan
Write-Host "  Coca Fria - Build llama.cpp" -ForegroundColor Cyan
Write-Host "===================================" -ForegroundColor Cyan
Write-Host ""

# Verificar se Git está instalado
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "ERRO: Git não está instalado!" -ForegroundColor Red
    Write-Host "Instale o Git em: https://git-scm.com/download/win" -ForegroundColor Yellow
    exit 1
}

# Verificar se CMake está instalado
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    Write-Host "ERRO: CMake não está instalado!" -ForegroundColor Red
    Write-Host "Instale o CMake em: https://cmake.org/download/" -ForegroundColor Yellow
    exit 1
}

# Verificar se compilador C++ está disponível
if (-not (Get-Command cl -ErrorAction SilentlyContinue)) {
    Write-Host "AVISO: Visual Studio C++ compiler não encontrado!" -ForegroundColor Yellow
    Write-Host "Instale Visual Studio Build Tools ou Visual Studio Community" -ForegroundColor Yellow
    Write-Host "Download: https://visualstudio.microsoft.com/downloads/" -ForegroundColor Yellow
    Write-Host ""
}

$llamaDir = "llama.cpp-repo"

# Clonar repositório se não existir
if (-not (Test-Path $llamaDir)) {
    Write-Host "Clonando repositório llama.cpp..." -ForegroundColor Green
    git clone https://github.com/ggerganov/llama.cpp.git $llamaDir
} else {
    Write-Host "Repositório já existe. Atualizando..." -ForegroundColor Green
    Set-Location $llamaDir
    git pull
    Set-Location ..
}

# Criar diretório de build
Write-Host "Criando diretório de build..." -ForegroundColor Green
Set-Location $llamaDir
New-Item -ItemType Directory -Force -Path build | Out-Null
Set-Location build

# Configurar com CMake
Write-Host "Configurando com CMake..." -ForegroundColor Green
cmake .. -DLLAMA_CUBLAS=ON

# Compilar
Write-Host "Compilando... (isso pode demorar alguns minutos)" -ForegroundColor Green
cmake --build . --config Release

# Copiar binário para pasta bin
Write-Host "Copiando binário..." -ForegroundColor Green
$binPath = "../../bin"
New-Item -ItemType Directory -Force -Path $binPath | Out-Null

if (Test-Path "bin/Release/main.exe") {
    Copy-Item "bin/Release/main.exe" $binPath
    Write-Host "✅ Build concluído com sucesso!" -ForegroundColor Green
    Write-Host "Binário: llama.cpp/bin/main.exe" -ForegroundColor Cyan
} elseif (Test-Path "Release/main.exe") {
    Copy-Item "Release/main.exe" $binPath
    Write-Host "✅ Build concluído com sucesso!" -ForegroundColor Green
    Write-Host "Binário: llama.cpp/bin/main.exe" -ForegroundColor Cyan
} else {
    Write-Host "❌ Erro: main.exe não encontrado após build" -ForegroundColor Red
    exit 1
}

Set-Location ../..

Write-Host ""
Write-Host "Próximos passos:" -ForegroundColor Yellow
Write-Host "1. Baixe o modelo LLaMA-Pro-8B-Instruct.gguf" -ForegroundColor White
Write-Host "2. Coloque em: llama.cpp/models/" -ForegroundColor White
Write-Host "3. Mude 'mode: llama' no backend-python/config.yaml" -ForegroundColor White
Write-Host "4. Reinicie o backend Python" -ForegroundColor White
