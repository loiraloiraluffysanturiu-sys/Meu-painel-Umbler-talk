# COCA FRIA - Sistema Multi-Agente WhatsApp com IA Local

## Visão Geral
Sistema multi-agente para WhatsApp com capacidades de IA local, desenvolvido para rodar tanto no Replit (desenvolvimento) quanto em Windows (produção) sem necessidade de Docker ou configurações manuais.

**Idioma:** Português Brasileiro (todas as interfaces)  
**Tema Visual:** Neon dark com glassmorphism  
**Banco de Dados:** SQLite (better-sqlite3)  
**Arquitetura:** Dual backend (Node.js + Python) + React frontend

## Status Atual
✅ **API Backend funcionando perfeitamente** (Node.js + Express)  
✅ **Banco de Dados SQLite integrado** (cocaDb module)  
✅ **Frontend React com Vite** integrado na porta 5000  
✅ **Rotas API operacionais** (workaround Vite implementado)  
⏳ Backend Python (IA local) - pendente  
⏳ Integração WhatsApp - pendente

## Arquitetura Técnica

### Backend Node.js (server/)
- **Express server** na porta 5000
- **API Routes** em `/server/index.ts`
- **Database** em `/server/coca-db.ts` (SQLite wrapper)
- **Vite integration** em `/server/vite.ts`

**Workaround Crítico:** Todas as rotas API usam `res.end()` com headers explícitos ao invés de `res.json()` para prevenir interceptação do Vite middleware. Ver `TECH_NOTES.md`.

### Frontend React (client/)
- **React + Vite** servido pelo Express
- **Páginas principais:**
  - `/` - Lista de agentes (`AgentsList.jsx`)
  - `/wizard` - Criar agente (`AgentWizard.jsx`)
  - `/agent/:id` - Detalhes do agente (`AgentDetail.jsx`)
- **Componentes UI:** Neon dark theme + glassmorphism

### Base de Dados (database/)
- **SQLite** file-based: `database/coca.db`
- **Schema:** `database/schema.sql`
- **Tabelas:**
  - `agents` - Agentes configurados
  - `knowledge_base` - Base de conhecimento
  - `conversations` - Histórico de mensagens

## Rotas API Implementadas

### Agentes
- `GET /api/agents` - Listar todos os agentes
- `GET /api/agents/:id` - Obter agente específico
- `POST /api/agents` - Criar novo agente
- `PUT /api/agents/:id` - Atualizar agente
- `DELETE /api/agents/:id` - Excluir agente
- `POST /api/agents/:id/clone` - Clonar agente
- `POST /api/agents/:id/knowledge` - Adicionar conhecimento

### Mensagens
- `GET /api/messages/conversations/:agent_id` - Listar conversas
- `POST /api/messages/send` - Enviar mensagem
- `POST /api/messages/simulate` - Simular mensagem recebida

### WhatsApp
- `POST /api/agents/:id/connect-whatsapp` - Conectar WhatsApp (stub)

## Desenvolvimento Local (Replit)

### Executar
```bash
npm run dev
```
Acessa em: https://[replit-url].replit.dev (porta 5000)

### Estrutura de Pastas
```
├── client/              # Frontend React
│   ├── src/
│   │   ├── pages/       # Páginas principais
│   │   ├── components/  # Componentes reutilizáveis
│   │   └── App.jsx      # Root component
├── server/              # Backend Node.js
│   ├── index.ts         # Express + API routes
│   ├── coca-db.ts       # SQLite wrapper
│   └── vite.ts          # Vite integration
├── database/            # SQLite database
│   ├── coca.db          # Database file
│   └── schema.sql       # Schema SQL
├── python_backend/      # Backend Python (pendente)
└── scripts/             # Windows automation
```

## Deploy Windows

### Pré-requisitos
- Node.js 18+ instalado
- Python 3.10+ instalado (para IA local)
- Porta 5000 disponível

### Instalação Automática
1. Clone/download o projeto
2. Execute: `start.bat`
3. Acesse: http://localhost:5000

O script `start.bat` automaticamente:
- Instala dependências npm
- Cria database se não existir
- Inicia backend Node.js
- Inicia backend Python (quando implementado)
- Abre navegador

## Pendências Principais

### Backend Python
- [ ] Implementar servidor FastAPI em `python_backend/main.py`
- [ ] Integrar modelos LLM locais (Ollama/LlamaCPP)
- [ ] API de processamento de linguagem natural

### Integração WhatsApp
- [ ] Integrar whatsapp-web.js no backend Node.js
- [ ] QR Code authentication flow
- [ ] Webhook para mensagens recebidas

### Frontend
- [ ] Implementar tema neon dark completo
- [ ] Adicionar efeitos glassmorphism
- [ ] Dashboard de monitoramento

## Referências Técnicas
- `TECH_NOTES.md` - Notas técnicas e workarounds
- `COMO_USAR_WINDOWS.md` - Guia de uso Windows
- `README.md` - Documentação principal

## Notas de Desenvolvimento
- **Replit limitation:** Apenas porta 5000 é acessível
- **Vite workaround:** Usar `res.end()` com headers ao invés de `res.json()`
- **Database:** SQLite file persiste entre restarts
- **Logs:** Verificar console para debug de API
