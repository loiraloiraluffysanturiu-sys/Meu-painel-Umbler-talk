# Design Guidelines: Real Estate Proposal Generator

## Design Approach
**System-Based Approach** using modern productivity tool patterns, drawing inspiration from Linear, Notion, and Asana. This utility-focused business application prioritizes efficiency, clarity, and professional presentation while maintaining visual polish.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 217 91% 60% (Professional blue)
- Primary Hover: 217 91% 50%
- Background: 0 0% 100%
- Surface: 220 13% 97%
- Border: 220 13% 91%
- Text Primary: 222 47% 11%
- Text Secondary: 215 16% 47%
- Success: 142 71% 45%
- Warning: 38 92% 50%

**Dark Mode:**
- Primary: 217 91% 60%
- Primary Hover: 217 91% 70%
- Background: 222 47% 11%
- Surface: 217 33% 17%
- Border: 217 33% 24%
- Text Primary: 210 40% 98%
- Text Secondary: 215 20% 65%
- Success: 142 71% 45%
- Warning: 38 92% 50%

### B. Typography
- **Headings**: Inter (600-700 weight) - Sizes: 2xl, xl, lg
- **Body**: Inter (400-500 weight) - Sizes: base, sm
- **Monospace**: JetBrains Mono (400) for data/numbers

### C. Layout System
Consistent spacing using Tailwind units: **2, 4, 6, 8, 12, 16, 24**
- Component padding: p-6 or p-8
- Section spacing: space-y-6 or space-y-8
- Container max-width: max-w-7xl
- Form layouts: max-w-4xl

### D. Component Library

**Navigation:**
- Sidebar: Fixed left navigation (w-64) with collapsible sections
- Top bar: Breadcrumbs, user profile, backup status indicator
- Icons: Heroicons (outline for navigation, solid for actions)

**Forms & Inputs:**
- Input fields: Rounded-lg border with focus ring, dark mode compatible
- Labels: Text-sm font-medium mb-2
- Rich text editor: Tiptap-style toolbar for proposal content
- Property details form: Multi-step wizard with progress indicator

**Data Display:**
- Proposal cards: Grid layout with preview, status badges, actions
- Property comparison table: Sticky headers, zebra striping
- Document preview: Side-by-side markdown/rendered view
- Backup status: Toast notifications with cloud sync icon

**Actions:**
- Primary buttons: Solid bg-primary with white text
- Secondary buttons: Border with transparent bg
- Danger actions: Red for delete/discard
- Quick actions: Icon-only buttons with tooltips

**Modals & Overlays:**
- Templates library: Full-screen modal with search and filters
- Backup settings: Slide-over panel from right
- Export options: Dropdown menu with format selection
- Confirmation dialogs: Centered modal with backdrop blur

### E. Key Screens Layout

**Dashboard:**
- Recent proposals grid (3 columns desktop, 1 mobile)
- Quick stats cards showing proposal count, pending reviews
- Backup status widget in top-right
- "New Proposal" prominent CTA button

**Proposal Editor:**
- Two-panel layout: Form inputs (left) | Live preview (right)
- Floating toolbar with save, export, template actions
- Auto-save indicator with last backup timestamp
- Property details section with expandable fields

**Template Library:**
- Masonry grid of template cards with thumbnails
- Category filters (residential, commercial, luxury)
- Search bar with instant results
- Preview on hover, quick-use action

**Backup & Recovery:**
- Timeline view of auto-saved versions
- Side-by-side diff view for comparing versions
- One-click restore with confirmation
- Cloud provider connection status

## Animation
Minimal, purposeful motion:
- Page transitions: 150ms ease-in-out
- Dropdown/modal: Scale from 95% to 100%
- Save indicators: Subtle pulse on success
- No decorative animations

## Images
**No hero image required** - This is a utility tool focused on productivity. Use:
- Template thumbnails: Generated proposal previews
- Property placeholder images in forms
- User avatars for collaboration features
- Icon illustrations for empty states only

## Professional Polish
- Consistent 8px border radius across all components
- Subtle shadows: sm for cards, md for modals, lg for dropdowns
- Smooth state transitions on interactive elements
- Professional color-coded status badges (draft/pending/approved)
- Clear visual hierarchy through size, weight, and spacing