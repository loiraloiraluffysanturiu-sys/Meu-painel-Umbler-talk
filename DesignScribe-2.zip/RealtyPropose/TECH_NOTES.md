# Notas Técnicas - COCA FRIA

## Problema Crítico Resolvido: Vite Middleware Interceptando API

### Contexto
No Replit, o projeto usa configuração Vite + Express onde:
- Frontend e Backend compartilham a mesma porta (5000)
- Vite middleware é configurado para servir o frontend
- API routes precisam responder JSON corretamente

### Problema
O middleware do Vite (`server/vite.ts`) estava interceptando TODAS as respostas, incluindo APIs `/api/*`, causando:
- Frontend recebia HTML ao invés de JSON
- `res.json()` não funcionava para rotas API
- Erro: "SyntaxError: Unexpected token '<' in JSON"

### Solução Implementada
**Usar `res.end()` com headers explícitos ao invés de `res.json()`:**

```typescript
// ❌ NÃO FUNCIONA no Replit com Vite middleware
app.get('/api/agents', (req, res) => {
  const agents = cocaDb.getAgents();
  res.json(agents); // Vite intercepta e retorna HTML!
});

// ✅ FUNCIONA: Bypass do Vite middleware
app.get('/api/agents', (req, res) => {
  try {
    const agents = cocaDb.getAgents();
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(agents));
    return; // Previne processamento adicional
  } catch (error: any) {
    res.setHeader('Content-Type', 'application/json');
    res.status(500).end(JSON.stringify({ error: error.message }));
    return;
  }
});
```

### Por Que Funciona?
1. `res.setHeader()` define Content-Type explicitamente antes do Vite processar
2. `res.end()` finaliza a resposta imediatamente, prevenindo middleware adicional
3. `return` garante que nenhum código posterior execute

### Aplicação
TODAS as rotas API em `server/index.ts` foram atualizadas para usar este padrão:
- `/api/agents` (GET, POST)
- `/api/agents/:id` (GET, PUT, DELETE)
- `/api/agents/:id/clone` (POST)
- `/api/agents/:id/knowledge` (POST)
- `/api/messages/*` (GET, POST)

### Arquivos Modificados
- `server/index.ts` - Todas as rotas API atualizadas
- `server/coca-db.ts` - Módulo de banco SQLite
- `client/src/pages/*.jsx` - Frontend atualizado para usar URLs relativas

### Testado e Funcionando
✅ GET /api/agents - Retorna array JSON  
✅ POST /api/agents - Cria agente e retorna JSON  
✅ Frontend recebe JSON corretamente  
✅ Sem erros no console do navegador
