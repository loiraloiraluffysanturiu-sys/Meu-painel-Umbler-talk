import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import axios from 'axios';
import Button from '../components/ui/Button';
import Spinner from '../components/ui/Spinner';
import QrModal from '../components/QrModal';
import io from 'socket.io-client';

const API_URL = 'http://localhost:3001';

export default function AgentsList() {
  const navigate = useNavigate();
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [qrModal, setQrModal] = useState({ isOpen: false, qrCode: null, agentName: '' });
  const [socket, setSocket] = useState(null);

  useEffect(() => {
    loadAgents();
    
    const newSocket = io(`${API_URL}/app`);
    setSocket(newSocket);

    return () => newSocket.close();
  }, []);

  const loadAgents = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/agents`);
      setAgents(response.data);
    } catch (error) {
      console.error('Erro ao carregar agentes:', error);
      alert('Erro ao carregar agentes. Verifique se o backend está rodando.');
    } finally {
      setLoading(false);
    }
  };

  const handleConnect = async (agent) => {
    try {
      setQrModal({ isOpen: true, qrCode: null, agentName: agent.name });

      if (socket) {
        socket.on(`qr:${agent.id}`, (data) => {
          setQrModal({ isOpen: true, qrCode: data.qr, agentName: agent.name });
        });

        socket.on(`authenticated:${agent.id}`, () => {
          setQrModal({ isOpen: false, qrCode: null, agentName: '' });
          alert(`${agent.name} conectado com sucesso!`);
          loadAgents();
        });
      }

      await axios.post(`${API_URL}/api/agents/${agent.id}/connect-whatsapp?action=start`);
    } catch (error) {
      console.error('Erro ao conectar:', error);
      alert('Erro ao conectar WhatsApp');
      setQrModal({ isOpen: false, qrCode: null, agentName: '' });
    }
  };

  const handleDelete = async (id) => {
    if (confirm('Deseja realmente excluir este agente?')) {
      try {
        await axios.delete(`${API_URL}/api/agents/${id}`);
        loadAgents();
      } catch (error) {
        console.error('Erro ao excluir:', error);
        alert('Erro ao excluir agente');
      }
    }
  };

  const handleClone = async (id) => {
    try {
      await axios.post(`${API_URL}/api/agents/${id}/clone`);
      loadAgents();
    } catch (error) {
      console.error('Erro ao clonar:', error);
      alert('Erro ao clonar agente');
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '400px' }}>
        <Spinner size={50} />
      </div>
    );
  }

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <h1 className="neon-text" style={{ fontSize: '28px' }}>Meus Agentes</h1>
        <Button onClick={() => navigate('/agents/new')}>
          ➕ Novo Agente
        </Button>
      </div>

      {agents.length === 0 ? (
        <div className="glassmorphism" style={{ padding: '60px', textAlign: 'center' }}>
          <h3 style={{ color: '#888', marginBottom: '20px' }}>Nenhum agente cadastrado</h3>
          <Button onClick={() => navigate('/agents/new')}>Criar Primeiro Agente</Button>
        </div>
      ) : (
        <div className="glassmorphism" style={{ padding: '20px', overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '1px solid rgba(0, 217, 255, 0.3)' }}>
                <th style={{ padding: '15px', textAlign: 'left', color: '#00d9ff' }}>Nome</th>
                <th style={{ padding: '15px', textAlign: 'left', color: '#00d9ff' }}>Tipo</th>
                <th style={{ padding: '15px', textAlign: 'left', color: '#00d9ff' }}>Descrição</th>
                <th style={{ padding: '15px', textAlign: 'center', color: '#00d9ff' }}>Ações</th>
              </tr>
            </thead>
            <tbody>
              {agents.map((agent) => (
                <motion.tr
                  key={agent.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  style={{ borderBottom: '1px solid rgba(255, 255, 255, 0.1)' }}
                >
                  <td style={{ padding: '15px' }}>{agent.name}</td>
                  <td style={{ padding: '15px' }}>
                    <span style={{
                      background: 'rgba(0, 217, 255, 0.2)',
                      padding: '4px 12px',
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}>
                      {agent.type || 'Geral'}
                    </span>
                  </td>
                  <td style={{ padding: '15px', color: '#b0b0b0', maxWidth: '300px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    {agent.description || '-'}
                  </td>
                  <td style={{ padding: '15px' }}>
                    <div style={{ display: 'flex', gap: '10px', justifyContent: 'center' }}>
                      <button 
                        className="btn-primary" 
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        onClick={() => navigate(`/agents/${agent.id}`)}
                      >
                        Ver
                      </button>
                      <button 
                        className="btn-secondary" 
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        onClick={() => handleConnect(agent)}
                      >
                        Conectar
                      </button>
                      <button 
                        className="btn-secondary" 
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        onClick={() => handleClone(agent.id)}
                      >
                        Clonar
                      </button>
                      <button 
                        className="btn-danger" 
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                        onClick={() => handleDelete(agent.id)}
                      >
                        Excluir
                      </button>
                    </div>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <QrModal
        isOpen={qrModal.isOpen}
        onClose={() => setQrModal({ isOpen: false, qrCode: null, agentName: '' })}
        qrCode={qrModal.qrCode}
        agentName={qrModal.agentName}
      />
    </div>
  );
}
