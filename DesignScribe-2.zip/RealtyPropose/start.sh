#!/bin/bash
# Script para iniciar Coca Fria em Linux/Mac (Replit)

echo "==================================="
echo "      COCA FRIA - Iniciando"
echo "==================================="
echo ""

# Cores
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Verificar Node.js
if ! command -v node &> /dev/null; then
    echo "ERRO: Node.js não instalado!"
    exit 1
fi

# Verificar Python
if ! command -v python3 &> /dev/null && ! command -v python &> /dev/null; then
    echo "ERRO: Python não instalado!"
    exit 1
fi

PYTHON_CMD=$(command -v python3 || command -v python)

echo -e "${CYAN}[1/3] Instalando dependências Node.js...${NC}"
cd backend-node
if [ ! -d "node_modules" ]; then
    npm install
fi
cd ..

echo ""
echo -e "${CYAN}[2/3] Instalando dependências Python...${NC}"
cd backend-python
if [ ! -d "venv" ]; then
    $PYTHON_CMD -m venv venv
fi
source venv/bin/activate
pip install -r requirements.txt
deactivate
cd ..

echo ""
echo -e "${CYAN}[3/3] Instalando dependências Frontend...${NC}"
cd frontend
if [ ! -d "node_modules" ]; then
    npm install
fi
cd ..

echo ""
echo "==================================="
echo "   Iniciando serviços..."
echo "==================================="
echo ""

# Criar arquivo .env para backend-node se não existir
if [ ! -f "backend-node/.env" ]; then
    cp backend-node/.env.example backend-node/.env 2>/dev/null || true
fi

# Iniciar Backend Node.js em background
cd backend-node
node index.js > ../logs/node.log 2>&1 &
NODE_PID=$!
echo -e "${GREEN}✓ Backend Node.js iniciado (PID: $NODE_PID)${NC}"
cd ..

sleep 2

# Iniciar Backend Python em background
cd backend-python
source venv/bin/activate
python app.py > ../logs/python.log 2>&1 &
PYTHON_PID=$!
echo -e "${GREEN}✓ Backend Python iniciado (PID: $PYTHON_PID)${NC}"
deactivate
cd ..

sleep 2

# Iniciar Frontend
cd frontend
npm run dev > ../logs/frontend.log 2>&1 &
FRONTEND_PID=$!
echo -e "${GREEN}✓ Frontend iniciado (PID: $FRONTEND_PID)${NC}"
cd ..

echo ""
echo "==================================="
echo "   COCA FRIA INICIADO!"
echo "==================================="
echo ""
echo -e "${CYAN}Backend Node.js:${NC} http://localhost:3001"
echo -e "${CYAN}Backend Python:${NC}  http://localhost:8000"
echo -e "${CYAN}Frontend:${NC}        http://localhost:5173"
echo ""
echo -e "${YELLOW}Para parar os serviços:${NC}"
echo "  kill $NODE_PID $PYTHON_PID $FRONTEND_PID"
echo ""
echo "Pressione Ctrl+C para encerrar..."

# Esperar interrupção
wait
