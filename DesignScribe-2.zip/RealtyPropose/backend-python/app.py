from flask import Flask, request, jsonify
from flask_cors import CORS
import yaml
import os
import logging
from datetime import datetime
from llama_adapter import chat_with_llama

app = Flask(__name__)
CORS(app)

log_dir = '../logs'
os.makedirs(log_dir, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(os.path.join(log_dir, 'python.log')),
        logging.StreamHandler()
    ]
)

logger = logging.getLogger(__name__)

with open('config.yaml', 'r') as f:
    config = yaml.safe_load(f)

MODE = config.get('mode', 'demo')
MODEL_PATH = config.get('model_path', '../llama.cpp/models/LLaMA-Pro-8B-Instruct.gguf')
LLAMA_TEMPLATE = config.get('llama_command_template', '../llama.cpp/bin/main -m {model} --n-gpu-layers 20 --threads 4')
HOST = config.get('host', '0.0.0.0')
PORT = config.get('port', 8000)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'ok',
        'service': 'coca-fria-python',
        'mode': MODE
    })

@app.route('/api/generate', methods=['POST'])
def generate():
    try:
        data = request.json
        agent_id = data.get('agent_id')
        prompt = data.get('prompt', '')
        max_tokens = data.get('max_tokens', 500)
        temperature = data.get('temperature', 0.7)
        history = data.get('history', [])
        
        if not prompt:
            return jsonify({'error': 'Prompt é obrigatório'}), 400
        
        logger.info(f"Gerando resposta para agente {agent_id}: {prompt[:50]}...")
        
        if MODE == 'demo':
            response_text = f"[DEMO MODE] Olá! Recebi sua mensagem: '{prompt}'. Este é o modo demonstração. Para usar IA real, configure o modo 'llama' no config.yaml e adicione o modelo em llama.cpp/models/"
            
            return jsonify({
                'response': response_text,
                'agent_id': agent_id,
                'demo': True,
                'timestamp': datetime.now().isoformat()
            })
        
        elif MODE == 'llama':
            if not os.path.exists(MODEL_PATH):
                error_msg = f"Modelo não encontrado em {MODEL_PATH}. Por favor, adicione LLaMA-Pro-8B-Instruct.gguf no diretório llama.cpp/models/ ou mude para modo 'demo' no config.yaml"
                logger.error(error_msg)
                return jsonify({'error': error_msg}), 500
            
            llama_bin = '../llama.cpp/bin/main'
            if not os.path.exists(llama_bin):
                error_msg = f"Binário llama.cpp não encontrado em {llama_bin}. Execute o script de build ou mude para modo 'demo'"
                logger.error(error_msg)
                return jsonify({'error': error_msg}), 500
            
            try:
                response_text = chat_with_llama(
                    prompt=prompt,
                    model=MODEL_PATH,
                    template=LLAMA_TEMPLATE,
                    timeout=60
                )
                
                return jsonify({
                    'response': response_text,
                    'agent_id': agent_id,
                    'demo': False,
                    'timestamp': datetime.now().isoformat()
                })
                
            except Exception as e:
                logger.error(f"Erro ao executar llama.cpp: {str(e)}")
                return jsonify({
                    'error': f'Erro ao processar com llama.cpp: {str(e)}. Considere mudar para modo demo.',
                    'suggestion': 'Altere mode para "demo" no config.yaml'
                }), 500
        
        else:
            return jsonify({'error': f'Modo inválido: {MODE}. Use "demo" ou "llama"'}), 400
            
    except Exception as e:
        logger.error(f"Erro no endpoint /api/generate: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/config', methods=['GET'])
def get_config():
    return jsonify({
        'mode': MODE,
        'model_path': MODEL_PATH,
        'model_exists': os.path.exists(MODEL_PATH) if MODE == 'llama' else None
    })

if __name__ == '__main__':
    logger.info(f"🐍 Iniciando backend Python - Modo: {MODE}")
    logger.info(f"📍 Servidor rodando em {HOST}:{PORT}")
    
    if MODE == 'llama':
        if os.path.exists(MODEL_PATH):
            logger.info(f"✅ Modelo encontrado: {MODEL_PATH}")
        else:
            logger.warning(f"⚠️  Modelo não encontrado: {MODEL_PATH}")
            logger.warning(f"   Rodando em modo fallback. Configure o modelo para usar IA real.")
    
    app.run(host=HOST, port=PORT, debug=False)
