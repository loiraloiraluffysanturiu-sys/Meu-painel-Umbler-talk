import subprocess
import logging
import time

logger = logging.getLogger(__name__)

def run_command_get_output(cmd, input_text=None, timeout=60):
    """
    Executa comando e retorna stdout
    """
    try:
        logger.info(f"Executando comando: {cmd[:100]}...")
        
        process = subprocess.Popen(
            cmd,
            shell=True,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        try:
            stdout, stderr = process.communicate(input=input_text, timeout=timeout)
            
            if process.returncode != 0:
                logger.error(f"Comando falhou com código {process.returncode}")
                logger.error(f"stderr: {stderr}")
                raise Exception(f"Comando falhou: {stderr}")
            
            return stdout.strip()
            
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            raise Exception(f"Timeout após {timeout}s. Output parcial: {stdout[:200]}")
            
    except Exception as e:
        logger.error(f"Erro ao executar comando: {str(e)}")
        raise

def chat_with_llama(prompt, model, template, timeout=60):
    """
    Executa llama.cpp com o prompt fornecido
    """
    try:
        cmd = template.replace('{model}', model)
        
        formatted_prompt = f"""### Instrução:
Você é um assistente útil e amigável.

### Pergunta:
{prompt}

### Resposta:
"""
        
        logger.info(f"Enviando prompt para llama.cpp (tamanho: {len(formatted_prompt)} chars)")
        
        output = run_command_get_output(cmd, input_text=formatted_prompt, timeout=timeout)
        
        if not output:
            return "[Resposta vazia do modelo]"
        
        lines = output.split('\n')
        response_lines = []
        capture = False
        
        for line in lines:
            if '### Resposta:' in line:
                capture = True
                continue
            if capture and line.strip():
                response_lines.append(line.strip())
        
        response = ' '.join(response_lines) if response_lines else output[:500]
        
        logger.info(f"Resposta recebida: {response[:100]}...")
        return response
        
    except Exception as e:
        logger.error(f"Erro no chat_with_llama: {str(e)}")
        raise Exception(f"Falha ao processar com llama.cpp: {str(e)}")

def test_llama_availability(model_path, bin_path):
    """
    Testa se llama.cpp está disponível e funcional
    """
    import os
    
    if not os.path.exists(model_path):
        return False, f"Modelo não encontrado: {model_path}"
    
    if not os.path.exists(bin_path):
        return False, f"Binário não encontrado: {bin_path}"
    
    try:
        cmd = f"{bin_path} -m {model_path} -n 10 -p 'test'"
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            return True, "llama.cpp operacional"
        else:
            return False, f"Erro ao executar: {result.stderr[:200]}"
            
    except Exception as e:
        return False, f"Erro ao testar: {str(e)}"
