require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const winston = require('winston');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');

const db = require('./services/db');
const agentsRoutes = require('./routes/agents');
const messagesRoutes = require('./routes/messages');
const { initializeSocket } = require('./sockets/socketServer');

const PORT = process.env.PORT || 3001;
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173';

const logDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: path.join(logDir, 'node.log') }),
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: FRONTEND_URL,
    methods: ['GET', 'POST']
  }
});

app.use(cors({ origin: FRONTEND_URL }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(morgan('combined', {
  stream: { write: (message) => logger.info(message.trim()) }
}));

app.set('io', io);

app.use('/api/agents', agentsRoutes);
app.use('/api/messages', messagesRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', service: 'coca-fria-backend' });
});

initializeSocket(io);

async function startServer() {
  try {
    await db.initDb();
    logger.info('Banco de dados inicializado');
    
    server.listen(PORT, () => {
      logger.info(`🚀 Backend Node.js rodando na porta ${PORT}`);
      logger.info(`📡 Socket.IO disponível em http://localhost:${PORT}/app`);
      console.log(`\n✅ Backend Node.js iniciado com sucesso!`);
      console.log(`   Porta: ${PORT}`);
      console.log(`   Frontend: ${FRONTEND_URL}\n`);
    });
  } catch (error) {
    logger.error('Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

startServer();
