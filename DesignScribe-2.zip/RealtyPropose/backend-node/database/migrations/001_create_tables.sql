PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Agents (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  type TEXT,
  description TEXT,
  behavior TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_agents_name ON Agents(name);

CREATE TABLE IF NOT EXISTS KnowledgeItems (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL,
  title TEXT,
  content TEXT,
  metadata TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(agent_id) REFERENCES Agents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_knowledge_agent ON KnowledgeItems(agent_id);

CREATE TABLE IF NOT EXISTS Channels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL,
  type TEXT,
  session_path TEXT,
  status TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(agent_id) REFERENCES Agents(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_channels_agent ON Channels(agent_id);

CREATE TABLE IF NOT EXISTS Conversations (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  agent_id TEXT NOT NULL,
  channel_id INTEGER,
  role TEXT,
  sender TEXT,
  message_text TEXT,
  metadata TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(agent_id) REFERENCES Agents(id) ON DELETE CASCADE,
  FOREIGN KEY(channel_id) REFERENCES Channels(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_conversations_agent ON Conversations(agent_id);
CREATE INDEX IF NOT EXISTS idx_conversations_channel ON Conversations(channel_id);
