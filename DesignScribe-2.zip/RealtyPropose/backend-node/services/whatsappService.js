const axios = require('axios');
const QRCode = require('qrcode');
const { insertConversation, updateChannelStatus } = require('./db');

const clients = new Map();
const PYTHON_API_URL = process.env.PYTHON_API_URL || 'http://localhost:8000';

async function startClient(agent_id, io) {
  console.log(`[WhatsApp] Iniciando cliente simulado para agente: ${agent_id}`);
  
  if (clients.has(agent_id)) {
    console.log(`[WhatsApp] Cliente já existe para: ${agent_id}`);
    return;
  }
  
  const clientData = {
    agent_id,
    status: 'connecting',
    connected: false,
    sessionData: null
  };
  
  clients.set(agent_id, clientData);
  
  try {
    const qrData = `coca-fria-agent-${agent_id}-${Date.now()}`;
    const qrCodeDataURL = await QRCode.toDataURL(qrData);
    
    io.of('/app').emit(`qr:${agent_id}`, {
      qr: qrCodeDataURL,
      agent_id
    });
    
    setTimeout(async () => {
      clientData.status = 'authenticated';
      clientData.connected = true;
      
      await updateChannelStatus(agent_id, 'connected');
      
      io.of('/app').emit(`authenticated:${agent_id}`, {
        agent_id,
        status: 'connected'
      });
      
      io.of('/app').emit(`ready:${agent_id}`, {
        agent_id,
        message: 'Cliente WhatsApp conectado com sucesso'
      });
      
      console.log(`[WhatsApp] Cliente conectado: ${agent_id}`);
    }, 3000);
    
  } catch (error) {
    console.error(`[WhatsApp] Erro ao iniciar cliente ${agent_id}:`, error);
    throw error;
  }
}

async function disconnectClient(agent_id) {
  console.log(`[WhatsApp] Desconectando cliente: ${agent_id}`);
  
  if (clients.has(agent_id)) {
    clients.delete(agent_id);
    await updateChannelStatus(agent_id, 'disconnected');
    console.log(`[WhatsApp] Cliente desconectado: ${agent_id}`);
  }
}

async function sendMessage(agent_id, to, text, io) {
  console.log(`[WhatsApp] Enviando mensagem de ${agent_id} para ${to}`);
  
  const client = clients.get(agent_id);
  if (!client || !client.connected) {
    throw new Error('Cliente WhatsApp não conectado');
  }
  
  await insertConversation({
    agent_id,
    role: 'agent',
    sender: agent_id,
    message_text: text,
    metadata: JSON.stringify({ to })
  });
  
  if (io) {
    io.of('/app').emit(`message:${agent_id}`, {
      agent_id,
      from: agent_id,
      to,
      text,
      timestamp: new Date().toISOString()
    });
  }
  
  return { success: true, message: 'Mensagem enviada' };
}

async function handleIncomingMessage(agent_id, from, messageText, io) {
  console.log(`[WhatsApp] Mensagem recebida para ${agent_id} de ${from}: ${messageText}`);
  
  await insertConversation({
    agent_id,
    role: 'user',
    sender: from,
    message_text: messageText
  });
  
  try {
    const response = await axios.post(
      `${PYTHON_API_URL}/api/generate`,
      {
        agent_id,
        prompt: messageText,
        max_tokens: 500,
        temperature: 0.7
      },
      { timeout: 60000 }
    );
    
    const aiResponse = response.data.response || response.data.text || 'Sem resposta';
    
    await insertConversation({
      agent_id,
      role: 'agent',
      sender: agent_id,
      message_text: aiResponse,
      metadata: JSON.stringify({ to: from })
    });
    
    if (io) {
      io.of('/app').emit(`message:${agent_id}`, {
        agent_id,
        from: agent_id,
        to: from,
        text: aiResponse,
        timestamp: new Date().toISOString()
      });
    }
    
    return aiResponse;
    
  } catch (error) {
    console.error('[WhatsApp] Erro ao processar mensagem:', error.message);
    return '[Erro ao processar mensagem]';
  }
}

function simulateIncomingMessage(agent_id, from, text, io) {
  setTimeout(async () => {
    await handleIncomingMessage(agent_id, from, text, io);
  }, 1000);
}

module.exports = {
  startClient,
  disconnectClient,
  sendMessage,
  handleIncomingMessage,
  simulateIncomingMessage,
  clients
};
