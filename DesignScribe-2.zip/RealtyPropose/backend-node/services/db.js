const sqlite3 = require('sqlite3').verbose();
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, '../../database/db.sqlite');
const migrationPath = path.join(__dirname, '../database/migrations/001_create_tables.sql');

let db = null;

function initDb() {
  return new Promise((resolve, reject) => {
    db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('Erro ao abrir banco de dados:', err);
        return reject(err);
      }
      
      console.log('Conectado ao banco SQLite');
      
      const migration = fs.readFileSync(migrationPath, 'utf8');
      db.exec(migration, (err) => {
        if (err) {
          console.error('Erro ao executar migration:', err);
          return reject(err);
        }
        console.log('Migration aplicada com sucesso');
        resolve(db);
      });
    });
  });
}

function getAgents() {
  return new Promise((resolve, reject) => {
    db.all('SELECT * FROM Agents ORDER BY created_at DESC', [], (err, rows) => {
      if (err) return reject(err);
      resolve(rows);
    });
  });
}

function getAgentById(id) {
  return new Promise((resolve, reject) => {
    db.get('SELECT * FROM Agents WHERE id = ?', [id], (err, row) => {
      if (err) return reject(err);
      resolve(row);
    });
  });
}

function createAgent(agent) {
  return new Promise((resolve, reject) => {
    const { id, name, type, description, behavior } = agent;
    const behaviorStr = typeof behavior === 'object' ? JSON.stringify(behavior) : behavior;
    
    db.run(
      'INSERT INTO Agents (id, name, type, description, behavior) VALUES (?, ?, ?, ?, ?)',
      [id, name, type || '', description || '', behaviorStr || '{}'],
      function(err) {
        if (err) return reject(err);
        resolve({ id, name, type, description, behavior: behaviorStr });
      }
    );
  });
}

function updateAgent(id, updates) {
  return new Promise((resolve, reject) => {
    const { name, type, description, behavior } = updates;
    const behaviorStr = typeof behavior === 'object' ? JSON.stringify(behavior) : behavior;
    
    db.run(
      `UPDATE Agents SET 
        name = COALESCE(?, name),
        type = COALESCE(?, type),
        description = COALESCE(?, description),
        behavior = COALESCE(?, behavior),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?`,
      [name, type, description, behaviorStr, id],
      function(err) {
        if (err) return reject(err);
        if (this.changes === 0) return reject(new Error('Agente não encontrado'));
        resolve({ id, ...updates });
      }
    );
  });
}

function deleteAgent(id) {
  return new Promise((resolve, reject) => {
    db.run('DELETE FROM Agents WHERE id = ?', [id], function(err) {
      if (err) return reject(err);
      if (this.changes === 0) return reject(new Error('Agente não encontrado'));
      resolve({ deleted: true, id });
    });
  });
}

function insertConversation(data) {
  return new Promise((resolve, reject) => {
    const { agent_id, channel_id, role, sender, message_text, metadata } = data;
    const metadataStr = typeof metadata === 'object' ? JSON.stringify(metadata) : metadata;
    
    db.run(
      'INSERT INTO Conversations (agent_id, channel_id, role, sender, message_text, metadata) VALUES (?, ?, ?, ?, ?, ?)',
      [agent_id, channel_id || null, role, sender || '', message_text, metadataStr || '{}'],
      function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, ...data });
      }
    );
  });
}

function getConversationsByAgent(agent_id, limit = 100) {
  return new Promise((resolve, reject) => {
    db.all(
      'SELECT * FROM Conversations WHERE agent_id = ? ORDER BY created_at DESC LIMIT ?',
      [agent_id, limit],
      (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      }
    );
  });
}

function createChannel(channelData) {
  return new Promise((resolve, reject) => {
    const { agent_id, type, session_path, status } = channelData;
    
    db.run(
      'INSERT INTO Channels (agent_id, type, session_path, status) VALUES (?, ?, ?, ?)',
      [agent_id, type, session_path || '', status || 'disconnected'],
      function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, ...channelData });
      }
    );
  });
}

function updateChannelStatus(agent_id, status) {
  return new Promise((resolve, reject) => {
    db.run(
      'UPDATE Channels SET status = ? WHERE agent_id = ?',
      [status, agent_id],
      function(err) {
        if (err) return reject(err);
        resolve({ agent_id, status });
      }
    );
  });
}

function addKnowledge(agent_id, title, content, metadata = {}) {
  return new Promise((resolve, reject) => {
    const metadataStr = JSON.stringify(metadata);
    db.run(
      'INSERT INTO KnowledgeItems (agent_id, title, content, metadata) VALUES (?, ?, ?, ?)',
      [agent_id, title, content, metadataStr],
      function(err) {
        if (err) return reject(err);
        resolve({ id: this.lastID, agent_id, title, content, metadata: metadataStr });
      }
    );
  });
}

function getKnowledgeByAgent(agent_id) {
  return new Promise((resolve, reject) => {
    db.all(
      'SELECT * FROM KnowledgeItems WHERE agent_id = ? ORDER BY created_at DESC',
      [agent_id],
      (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      }
    );
  });
}

module.exports = {
  initDb,
  getAgents,
  getAgentById,
  createAgent,
  updateAgent,
  deleteAgent,
  insertConversation,
  getConversationsByAgent,
  createChannel,
  updateChannelStatus,
  addKnowledge,
  getKnowledgeByAgent
};
