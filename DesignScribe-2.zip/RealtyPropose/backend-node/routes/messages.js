const express = require('express');
const router = express.Router();
const db = require('../services/db');
const whatsappService = require('../services/whatsappService');

router.post('/send', async (req, res) => {
  try {
    const { agent_id, to, text } = req.body;
    
    if (!agent_id || !to || !text) {
      return res.status(400).json({ error: 'agent_id, to e text são obrigatórios' });
    }
    
    const io = req.app.get('io');
    const result = await whatsappService.sendMessage(agent_id, to, text, io);
    
    res.json(result);
  } catch (error) {
    console.error('Erro ao enviar mensagem:', error);
    res.status(500).json({ error: error.message || 'Erro ao enviar mensagem' });
  }
});

router.get('/conversations/:agent_id', async (req, res) => {
  try {
    const { agent_id } = req.params;
    const { limit } = req.query;
    
    const conversations = await db.getConversationsByAgent(agent_id, limit ? parseInt(limit) : 100);
    res.json(conversations);
  } catch (error) {
    console.error('Erro ao buscar conversas:', error);
    res.status(500).json({ error: 'Erro ao buscar conversas' });
  }
});

router.post('/simulate', async (req, res) => {
  try {
    const { agent_id, from, text } = req.body;
    
    if (!agent_id || !from || !text) {
      return res.status(400).json({ error: 'agent_id, from e text são obrigatórios' });
    }
    
    const io = req.app.get('io');
    whatsappService.simulateIncomingMessage(agent_id, from, text, io);
    
    res.json({ success: true, message: 'Mensagem simulada' });
  } catch (error) {
    console.error('Erro ao simular mensagem:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
