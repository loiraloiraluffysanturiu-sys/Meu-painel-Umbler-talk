const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const db = require('../services/db');
const whatsappService = require('../services/whatsappService');

router.get('/', async (req, res) => {
  try {
    const agents = await db.getAgents();
    res.json(agents);
  } catch (error) {
    console.error('Erro ao buscar agentes:', error);
    res.status(500).json({ error: 'Erro ao buscar agentes' });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const agent = await db.getAgentById(req.params.id);
    if (!agent) {
      return res.status(404).json({ error: 'Agente não encontrado' });
    }
    res.json(agent);
  } catch (error) {
    console.error('Erro ao buscar agente:', error);
    res.status(500).json({ error: 'Erro ao buscar agente' });
  }
});

router.post('/', async (req, res) => {
  try {
    const { name, type, description, behavior } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Nome é obrigatório' });
    }
    
    const id = req.body.id || uuidv4();
    const agent = await db.createAgent({ id, name, type, description, behavior });
    
    await db.createChannel({
      agent_id: id,
      type: 'whatsapp',
      status: 'disconnected'
    });
    
    res.status(201).json(agent);
  } catch (error) {
    console.error('Erro ao criar agente:', error);
    res.status(500).json({ error: 'Erro ao criar agente' });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const { name, type, description, behavior } = req.body;
    const agent = await db.updateAgent(req.params.id, { name, type, description, behavior });
    res.json(agent);
  } catch (error) {
    console.error('Erro ao atualizar agente:', error);
    res.status(500).json({ error: error.message || 'Erro ao atualizar agente' });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await whatsappService.disconnectClient(req.params.id);
    await db.deleteAgent(req.params.id);
    res.json({ success: true, message: 'Agente excluído' });
  } catch (error) {
    console.error('Erro ao deletar agente:', error);
    res.status(500).json({ error: error.message || 'Erro ao deletar agente' });
  }
});

router.post('/:id/clone', async (req, res) => {
  try {
    const original = await db.getAgentById(req.params.id);
    if (!original) {
      return res.status(404).json({ error: 'Agente não encontrado' });
    }
    
    const newId = uuidv4();
    const cloned = await db.createAgent({
      id: newId,
      name: `${original.name} (Cópia)`,
      type: original.type,
      description: original.description,
      behavior: original.behavior
    });
    
    await db.createChannel({
      agent_id: newId,
      type: 'whatsapp',
      status: 'disconnected'
    });
    
    res.status(201).json(cloned);
  } catch (error) {
    console.error('Erro ao clonar agente:', error);
    res.status(500).json({ error: 'Erro ao clonar agente' });
  }
});

router.post('/:id/connect-whatsapp', async (req, res) => {
  try {
    const { action } = req.query;
    const agent_id = req.params.id;
    
    const agent = await db.getAgentById(agent_id);
    if (!agent) {
      return res.status(404).json({ error: 'Agente não encontrado' });
    }
    
    if (action === 'restart') {
      await whatsappService.disconnectClient(agent_id);
    }
    
    const io = req.app.get('io');
    await whatsappService.startClient(agent_id, io);
    
    res.json({ success: true, message: 'Processo de conexão iniciado' });
  } catch (error) {
    console.error('Erro ao conectar WhatsApp:', error);
    res.status(500).json({ error: error.message || 'Erro ao conectar WhatsApp' });
  }
});

router.post('/:id/knowledge', async (req, res) => {
  try {
    const { title, content, metadata } = req.body;
    const agent_id = req.params.id;
    
    const knowledge = await db.addKnowledge(agent_id, title, content, metadata);
    res.status(201).json(knowledge);
  } catch (error) {
    console.error('Erro ao adicionar conhecimento:', error);
    res.status(500).json({ error: 'Erro ao adicionar conhecimento' });
  }
});

router.get('/:id/knowledge', async (req, res) => {
  try {
    const knowledge = await db.getKnowledgeByAgent(req.params.id);
    res.json(knowledge);
  } catch (error) {
    console.error('Erro ao buscar conhecimento:', error);
    res.status(500).json({ error: 'Erro ao buscar conhecimento' });
  }
});

module.exports = router;
