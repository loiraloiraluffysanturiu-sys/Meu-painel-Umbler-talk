function initializeSocket(io) {
  const appNamespace = io.of('/app');
  
  appNamespace.on('connection', (socket) => {
    console.log('[Socket] Cliente conectado:', socket.id);
    
    socket.on('subscribe', (data) => {
      const { agent_id } = data;
      console.log(`[Socket] Cliente ${socket.id} inscrito no agente ${agent_id}`);
      socket.join(`agent:${agent_id}`);
    });
    
    socket.on('unsubscribe', (data) => {
      const { agent_id } = data;
      console.log(`[Socket] Cliente ${socket.id} desinscrito do agente ${agent_id}`);
      socket.leave(`agent:${agent_id}`);
    });
    
    socket.on('send_message', async (data) => {
      const { agent_id, to, text } = data;
      console.log(`[Socket] Solicitação de envio de mensagem de ${agent_id} para ${to}`);
      
      appNamespace.to(`agent:${agent_id}`).emit(`message:${agent_id}`, {
        agent_id,
        from: agent_id,
        to,
        text,
        timestamp: new Date().toISOString()
      });
    });
    
    socket.on('simulate_incoming', async (data) => {
      const { agent_id, from, text } = data;
      console.log(`[Socket] Simulando mensagem recebida para ${agent_id}`);
      
      const whatsappService = require('../services/whatsappService');
      whatsappService.simulateIncomingMessage(agent_id, from, text, io);
    });
    
    socket.on('disconnect', () => {
      console.log('[Socket] Cliente desconectado:', socket.id);
    });
  });
  
  return appNamespace;
}

module.exports = { initializeSocket };
