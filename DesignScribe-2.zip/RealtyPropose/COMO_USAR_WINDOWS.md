# 🥤 COCA FRIA - Como Usar no Windows

## 🚀 Início Rápido (3 Passos)

### 1️⃣ Instalar Pré-requisitos

**Baixe e instale (se ainda não tiver):**

- **Node.js 18+**: https://nodejs.org/ (Escolha LTS)
- **Python 3.10+**: https://www.python.org/ 
  - ⚠️ Marque "Add Python to PATH" durante instalação!

### 2️⃣ Executar o Sistema

Abra o prompt de comando (CMD) na pasta do projeto e execute:

```bash
start.bat
```

**O script irá automaticamente:**
- ✅ Instalar todas as dependências Node.js e Python
- ✅ Iniciar 3 serviços (Backend Node, Backend Python, Frontend)
- ✅ Abrir o navegador no endereço http://localhost:5173

### 3️⃣ Usar o Sistema

1. **Criar um Agente:**
   - Clique em "➕ Novo Agente"
   - Preencha nome, tipo, comportamento
   - Adicione conhecimento (opcional)
   - Clique em "Criar Agente"

2. **Conectar WhatsApp:**
   - Na lista de agentes, clique em "Conectar"
   - Escaneie o QR Code com WhatsApp
   - Pronto! Agente conectado ✅

3. **Testar:**
   - Clique em "Ver" no agente
   - Use "Simular Mensagem" para testar
   - Ou envie mensagem real pelo WhatsApp

## 📱 Importante sobre WhatsApp

- Cada agente precisa de um **número WhatsApp diferente**
- Use WhatsApp Business ou números secundários
- A sessão fica salva automaticamente
- Para reconectar, clique em "Conectar" novamente

## 🧠 Modo de IA

### Modo DEMO (Padrão)
- Respostas simuladas para teste
- Funciona sem configuração adicional
- Ideal para aprender o sistema

### Modo LLAMA (IA Real - Avançado)

**Para ativar:**

1. **Compile o llama.cpp:**
   ```powershell
   cd llama.cpp
   .\build-windows.ps1
   ```
   
   Requisitos:
   - Git instalado
   - CMake instalado
   - Visual Studio Build Tools

2. **Baixe o modelo:**
   - Baixe: `LLaMA-Pro-8B-Instruct.gguf` (HuggingFace)
   - Coloque em: `llama.cpp/models/`

3. **Configure:**
   - Edite `backend-python/config.yaml`
   - Mude: `mode: demo` para `mode: llama`

4. **Reinicie o backend Python**

## 🔧 URLs dos Serviços

- **Frontend (Interface):** http://localhost:5173
- **API Node.js:** http://localhost:3001
- **API Python (IA):** http://localhost:8000

## ❓ Problemas Comuns

### Backend não inicia
```bash
# Verifique os logs:
type logs\node.log
type logs\python.log
```

### "npm não reconhecido"
- Node.js não instalado ou não no PATH
- Reinstale Node.js marcando "Add to PATH"

### "python não reconhecido"
- Python não no PATH
- Reinstale marcando "Add Python to PATH"

### Porta já em uso
Altere as portas em:
- `backend-node/.env` (PORT=3001)
- `backend-python/config.yaml` (port: 8000)
- `frontend/vite.config.ts` (port: 5173)

## 🛑 Parar o Sistema

Feche todas as janelas CMD que foram abertas pelo `start.bat`

Ou pressione `Ctrl+C` em cada janela.

## 📊 Estrutura de Pastas

```
coca-fria/
├── frontend/          # Interface React
├── backend-node/      # API Node.js + WhatsApp
├── backend-python/    # IA (demo ou llama)
├── database/          # Banco SQLite
├── llama.cpp/         # IA Local (opcional)
├── logs/              # Logs do sistema
└── start.bat          # ← EXECUTE ESTE
```

## 🎯 Próximos Passos

1. ✅ Execute `start.bat`
2. ✅ Acesse http://localhost:5173
3. ✅ Crie seu primeiro agente
4. ✅ Conecte ao WhatsApp
5. ✅ Teste e use!

---

**Dúvidas?** Consulte o README.md completo ou os logs em `logs/`

🥤 **Coca Fria** - Sistema Multi-Agente WhatsApp
