import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import cocaDb from "./coca-db";

export async function registerRoutes(app: Express): Promise<Server> {
  // Coca Fria API Routes
  
  // Agents
  app.get('/api/agents', async (req, res) => {
    try {
      const agents = cocaDb.getAgents();
      console.log('Agents from DB:', agents, 'Type:', Array.isArray(agents));
      res.json(agents);
    } catch (error: any) {
      console.error('Error in /api/agents:', error);
      res.status(500).json({ error: error.message });
    }
  });

  app.get('/api/agents/:id', async (req, res) => {
    try {
      const agent = cocaDb.getAgentById(req.params.id);
      if (!agent) {
        return res.status(404).json({ error: 'Agente não encontrado' });
      }
      res.json(agent);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/agents', async (req, res) => {
    try {
      const { name, type, description, behavior } = req.body;
      if (!name) {
        return res.status(400).json({ error: 'Nome é obrigatório' });
      }
      const agent = cocaDb.createAgent({ name, type, description, behavior });
      res.status(201).json(agent);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.put('/api/agents/:id', async (req, res) => {
    try {
      const { name, type, description, behavior } = req.body;
      const agent = cocaDb.updateAgent(req.params.id, { name, type, description, behavior });
      res.json(agent);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.delete('/api/agents/:id', async (req, res) => {
    try {
      const result = cocaDb.deleteAgent(req.params.id);
      res.json({ success: true, message: 'Agente excluído' });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/agents/:id/clone', async (req, res) => {
    try {
      const clonedAgent = cocaDb.cloneAgent(req.params.id);
      res.status(201).json(clonedAgent);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/agents/:id/knowledge', async (req, res) => {
    try {
      const { title, content, metadata } = req.body;
      const knowledge = cocaDb.addKnowledge(req.params.id, { title, content, metadata });
      res.status(201).json(knowledge);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Messages
  app.get('/api/messages/conversations/:agent_id', async (req, res) => {
    try {
      const conversations = cocaDb.getConversations(req.params.agent_id);
      res.json(conversations);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/messages/send', async (req, res) => {
    try {
      const { agent_id, to, text } = req.body;
      const conversation = cocaDb.insertConversation({
        agent_id,
        role: 'agent',
        sender: agent_id,
        message_text: text,
        metadata: { to }
      });
      res.status(201).json(conversation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  app.post('/api/messages/simulate', async (req, res) => {
    try {
      const { agent_id, from, text } = req.body;
      const conversation = cocaDb.insertConversation({
        agent_id,
        role: 'user',
        sender: from,
        message_text: text
      });
      res.status(201).json(conversation);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // WhatsApp connection (placeholder)
  app.post('/api/agents/:id/connect-whatsapp', async (req, res) => {
    res.json({ message: 'WhatsApp connection not available in Replit. Use local setup.' });
  });

  const httpServer = createServer(app);
  return httpServer;
}
