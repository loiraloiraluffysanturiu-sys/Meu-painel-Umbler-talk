import Database from 'better-sqlite3';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { randomUUID } from 'crypto';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const dbPath = join(__dirname, '../database/db.sqlite');
const db = new Database(dbPath);

// Criar tabelas se não existirem
db.exec(`
  CREATE TABLE IF NOT EXISTS Agents (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT,
    description TEXT,
    behavior TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS KnowledgeItems (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    title TEXT,
    content TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS Channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    type TEXT DEFAULT 'whatsapp',
    status TEXT DEFAULT 'disconnected',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS Conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id TEXT NOT NULL,
    channel_id INTEGER,
    role TEXT,
    sender TEXT,
    message_text TEXT,
    metadata TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (agent_id) REFERENCES Agents(id) ON DELETE CASCADE,
    FOREIGN KEY (channel_id) REFERENCES Channels(id) ON DELETE CASCADE
  );
`);

export const cocaDb = {
  getAgents: () => {
    return db.prepare('SELECT * FROM Agents ORDER BY created_at DESC').all();
  },

  getAgentById: (id: string) => {
    return db.prepare('SELECT * FROM Agents WHERE id = ?').get(id);
  },

  createAgent: (agent: { id?: string; name: string; type?: string; description?: string; behavior?: any }) => {
    const id = agent.id || randomUUID();
    const behaviorStr = typeof agent.behavior === 'object' ? JSON.stringify(agent.behavior) : agent.behavior;
    
    db.prepare(`
      INSERT INTO Agents (id, name, type, description, behavior)
      VALUES (?, ?, ?, ?, ?)
    `).run(id, agent.name, agent.type || '', agent.description || '', behaviorStr || '{}');

    db.prepare(`
      INSERT INTO Channels (agent_id, type, status)
      VALUES (?, 'whatsapp', 'disconnected')
    `).run(id);

    return { id, ...agent, behavior: behaviorStr };
  },

  updateAgent: (id: string, updates: { name?: string; type?: string; description?: string; behavior?: any }) => {
    const behaviorStr = updates.behavior && typeof updates.behavior === 'object' 
      ? JSON.stringify(updates.behavior) 
      : updates.behavior;

    db.prepare(`
      UPDATE Agents SET
        name = COALESCE(?, name),
        type = COALESCE(?, type),
        description = COALESCE(?, description),
        behavior = COALESCE(?, behavior),
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(updates.name, updates.type, updates.description, behaviorStr, id);

    return { id, ...updates };
  },

  deleteAgent: (id: string) => {
    db.prepare('DELETE FROM Agents WHERE id = ?').run(id);
    return { deleted: true, id };
  },

  cloneAgent: (id: string) => {
    const original = cocaDb.getAgentById(id) as any;
    if (!original) throw new Error('Agente não encontrado');

    const newId = randomUUID();
    const clonedAgent = {
      ...original,
      id: newId,
      name: `${original.name} (Cópia)`,
    };

    return cocaDb.createAgent(clonedAgent);
  },

  addKnowledge: (agentId: string, knowledge: { title: string; content: string; metadata?: any }) => {
    const metadataStr = knowledge.metadata && typeof knowledge.metadata === 'object'
      ? JSON.stringify(knowledge.metadata)
      : knowledge.metadata;

    const result = db.prepare(`
      INSERT INTO KnowledgeItems (agent_id, title, content, metadata)
      VALUES (?, ?, ?, ?)
    `).run(agentId, knowledge.title, knowledge.content, metadataStr || '{}');

    return { id: result.lastInsertRowid, agent_id: agentId, ...knowledge };
  },

  getConversations: (agentId: string, limit = 50) => {
    return db.prepare(`
      SELECT * FROM Conversations
      WHERE agent_id = ?
      ORDER BY created_at ASC
      LIMIT ?
    `).all(agentId, limit);
  },

  insertConversation: (data: {
    agent_id: string;
    role: string;
    sender: string;
    message_text: string;
    metadata?: any;
  }) => {
    const metadataStr = data.metadata && typeof data.metadata === 'object'
      ? JSON.stringify(data.metadata)
      : data.metadata;

    const result = db.prepare(`
      INSERT INTO Conversations (agent_id, role, sender, message_text, metadata)
      VALUES (?, ?, ?, ?, ?)
    `).run(data.agent_id, data.role, data.sender, data.message_text, metadataStr || '{}');

    return { id: result.lastInsertRowid, ...data };
  },
};

export default cocaDb;
